<template>
  <view 
    class="mui-chip"
    :class="[
      `mui-chip--${variant}`,
      `mui-chip--${size}`,
      `mui-chip--${color}`,
      { 'mui-chip--disabled': disabled }
    ]"
    :disabled="disabled"
    @click="handleClick"
  >
    <view v-if="icon" class="mui-chip__icon">
      <slot name="icon"></slot>
    </view>
    <view v-if="avatar" class="mui-chip__avatar">
      <slot name="avatar"></slot>
    </view>
    <text class="mui-chip__label">
      <slot></slot>
    </text>
    <view v-if="deletable" class="mui-chip__delete" @click.stop="handleDelete">
      <text>×</text>
    </view>
  </view>
</template>

<script>
export default {
  name: 'MuiChip',
  props: {
    variant: {
      type: String,
      default: 'filled',
      validator: (v) => ['filled', 'outlined'].includes(v)
    },
    size: {
      type: String,
      default: 'medium',
      validator: (v) => ['small', 'medium'].includes(v)
    },
    color: {
      type: String,
      default: 'default',
      validator: (v) => ['default', 'primary', 'secondary', 'error', 'warning', 'info', 'success'].includes(v)
    },
    icon: {
      type: Boolean,
      default: false
    },
    avatar: {
      type: Boolean,
      default: false
    },
    deletable: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  emits: ['click', 'delete'],
  methods: {
    handleClick(e) {
      if (!this.disabled) {
        this.$emit('click', e)
      }
    },
    handleDelete(e) {
      if (!this.disabled) {
        this.$emit('delete', e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-chip {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: $mui-radius-full;
  background-color: $mui-surface-variant;
  color: $mui-text-primary;
  transition: all 0.2s ease;
  cursor: pointer;
  user-select: none;

  &:active {
    opacity: 0.8;
  }

  &__icon {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  &__avatar {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  &__label {
    font-size: 28rpx;
    line-height: 1.5;
  }

  &__delete {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36rpx;
    line-height: 1;
    opacity: 0.7;
    
    &:active {
      opacity: 1;
    }
  }

  /* Variants */
  &--filled {
    background-color: $mui-surface-variant;
  }

  &--outlined {
    background-color: transparent;
    border: 1rpx solid $mui-border;
  }

  /* Sizes */
  &--small {
    height: 56rpx;
    padding: 0 12rpx;
    
    .mui-chip__icon,
    .mui-chip__avatar {
      width: 40rpx;
      height: 40rpx;
      margin-left: 4rpx;
      margin-right: -4rpx;
    }
    
    .mui-chip__label {
      font-size: 24rpx;
      padding: 0 12rpx;
    }
    
    .mui-chip__delete {
      width: 40rpx;
      height: 40rpx;
      margin-right: -4rpx;
      font-size: 32rpx;
    }
  }

  &--medium {
    height: 64rpx;
    padding: 0 16rpx;
    
    .mui-chip__icon,
    .mui-chip__avatar {
      width: 48rpx;
      height: 48rpx;
      margin-left: 4rpx;
      margin-right: -8rpx;
    }
    
    .mui-chip__label {
      font-size: 28rpx;
      padding: 0 16rpx;
    }
    
    .mui-chip__delete {
      width: 48rpx;
      height: 48rpx;
      margin-right: -8rpx;
    }
  }

  /* Colors */
  &--default {
    &.mui-chip--filled {
      background-color: $mui-surface-variant;
      color: $mui-text-primary;
    }
    &.mui-chip--outlined {
      border-color: $mui-border;
      color: $mui-text-primary;
    }
  }

  &--primary {
    &.mui-chip--filled {
      background-color: rgba($mui-primary, 0.12);
      color: $mui-primary-dark;
    }
    &.mui-chip--outlined {
      border-color: $mui-primary;
      color: $mui-primary;
    }
  }

  &--secondary {
    &.mui-chip--filled {
      background-color: rgba($mui-secondary, 0.12);
      color: $mui-secondary-dark;
    }
    &.mui-chip--outlined {
      border-color: $mui-secondary;
      color: $mui-secondary;
    }
  }

  &--error {
    &.mui-chip--filled {
      background-color: rgba($mui-error, 0.12);
      color: $mui-error-dark;
    }
    &.mui-chip--outlined {
      border-color: $mui-error;
      color: $mui-error;
    }
  }

  &--warning {
    &.mui-chip--filled {
      background-color: rgba($mui-warning, 0.12);
      color: $mui-warning-dark;
    }
    &.mui-chip--outlined {
      border-color: $mui-warning;
      color: $mui-warning;
    }
  }

  &--info {
    &.mui-chip--filled {
      background-color: rgba($mui-info, 0.12);
      color: $mui-info;
    }
    &.mui-chip--outlined {
      border-color: $mui-info;
      color: $mui-info;
    }
  }

  &--success {
    &.mui-chip--filled {
      background-color: rgba($mui-success, 0.12);
      color: $mui-success-dark;
    }
    &.mui-chip--outlined {
      border-color: $mui-success;
      color: $mui-success;
    }
  }

  /* States */
  &--disabled {
    opacity: 0.5;
    pointer-events: none;
  }
}
</style>
