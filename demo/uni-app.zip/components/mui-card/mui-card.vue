<template>
  <view class="mui-card" :class="{ 'mui-card--outlined': outlined, 'mui-card--elevated': elevated }">
    <view v-if="$slots.header" class="mui-card__header">
      <slot name="header"></slot>
    </view>
    <view v-if="$slots.media" class="mui-card__media">
      <slot name="media"></slot>
    </view>
    <view class="mui-card__content">
      <slot></slot>
    </view>
    <view v-if="$slots.actions" class="mui-card__actions">
      <slot name="actions"></slot>
    </view>
  </view>
</template>

<script>
export default {
  name: 'MuiCard',
  props: {
    outlined: {
      type: Boolean,
      default: false
    },
    elevated: {
      type: Boolean,
      default: true
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-card {
  background-color: $mui-surface;
  border-radius: $mui-radius-lg;
  overflow: hidden;
  transition: box-shadow 0.3s ease;

  &--elevated {
    box-shadow: $mui-shadow-1;
    
    &:active {
      box-shadow: $mui-shadow-2;
    }
  }

  &--outlined {
    border: 1rpx solid $mui-border;
    box-shadow: none;
  }

  &__header {
    padding: $mui-spacing-md $mui-spacing-md 0 $mui-spacing-md;
  }

  &__media {
    width: 100%;
    background-color: $mui-surface-variant;
  }

  &__content {
    padding: $mui-spacing-md;
  }

  &__actions {
    display: flex;
    align-items: center;
    padding: 0 $mui-spacing-sm $mui-spacing-sm $mui-spacing-sm;
  }
}
</style>
