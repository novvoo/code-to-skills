<template>
  <view 
    class="mui-divider"
    :class="[
      `mui-divider--${orientation}`,
      { 'mui-divider--inset': inset, 'mui-divider--light': light }
    ]"
  >
    <view v-if="$slots.default" class="mui-divider__wrapper">
      <view class="mui-divider__line mui-divider__line--left"></view>
      <view class="mui-divider__text">
        <slot></slot>
      </view>
      <view class="mui-divider__line mui-divider__line--right"></view>
    </view>
  </view>
</template>

<script>
export default {
  name: 'MuiDivider',
  props: {
    orientation: {
      type: String,
      default: 'horizontal',
      validator: (v) => ['horizontal', 'vertical'].includes(v)
    },
    inset: {
      type: Boolean,
      default: false
    },
    light: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-divider {
  display: block;
  flex-shrink: 0;

  /* Orientation */
  &--horizontal {
    width: 100%;
    height: 1rpx;
    background-color: $mui-border;
    margin: $mui-spacing-md 0;
  }

  &--vertical {
    width: 1rpx;
    height: 100%;
    background-color: $mui-border;
    margin: 0 $mui-spacing-md;
  }

  /* Inset */
  &--inset&--horizontal {
    margin-left: 88rpx;
    width: calc(100% - 88rpx);
  }

  /* Light */
  &--light {
    background-color: rgba(0, 0, 0, 0.06);
  }

  /* With text */
  &__wrapper {
    display: flex;
    align-items: center;
    width: 100%;
    margin: $mui-spacing-md 0;
  }

  &__line {
    flex: 1;
    height: 1rpx;
    background-color: $mui-border;
  }

  &__text {
    padding: 0 $mui-spacing-md;
    font-size: $mui-font-sm;
    color: $mui-text-secondary;
  }
}
</style>
