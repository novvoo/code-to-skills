<template>
  <view 
    class="mui-avatar"
    :class="[
      `mui-avatar--${variant}`,
      `mui-avatar--${size}`,
      { 'mui-avatar--with-color': color }
    ]"
    :style="avatarStyle"
  >
    <slot></slot>
  </view>
</template>

<script>
export default {
  name: 'MuiAvatar',
  props: {
    variant: {
      type: String,
      default: 'circular',
      validator: (v) => ['circular', 'rounded', 'square'].includes(v)
    },
    size: {
      type: String,
      default: 'medium',
      validator: (v) => ['small', 'medium', 'large'].includes(v)
    },
    src: {
      type: String,
      default: ''
    },
    color: {
      type: String,
      default: ''
    },
    textColor: {
      type: String,
      default: ''
    }
  },
  computed: {
    avatarStyle() {
      const style = {}
      if (this.src) {
        style.backgroundImage = `url(${this.src})`
        style.backgroundSize = 'cover'
        style.backgroundPosition = 'center'
      }
      if (this.color && !this.src) {
        style.backgroundColor = this.color
      }
      if (this.textColor) {
        style.color = this.textColor
      }
      return style
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-avatar {
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  font-weight: 500;
  background-color: $mui-surface-variant;
  color: $mui-text-secondary;

  /* Variants */
  &--circular {
    border-radius: 50%;
  }

  &--rounded {
    border-radius: $mui-radius-md;
  }

  &--square {
    border-radius: 0;
  }

  /* Sizes */
  &--small {
    width: 64rpx;
    height: 64rpx;
    font-size: 24rpx;
  }

  &--medium {
    width: 88rpx;
    height: 88rpx;
    font-size: 32rpx;
  }

  &--large {
    width: 128rpx;
    height: 128rpx;
    font-size: 48rpx;
  }

  &--with-color {
    color: $mui-text-on-primary;
  }
}
</style>
