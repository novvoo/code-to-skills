<template>
  <view 
    class="mui-button"
    :class="[
      `mui-button--${variant}`,
      `mui-button--${size}`,
      `mui-button--${color}`,
      { 'mui-button--disabled': disabled, 'mui-button--full': fullWidth }
    ]"
    :disabled="disabled"
    @click="handleClick"
  >
    <view v-if="icon && !loading" class="mui-button__icon" :style="{ marginRight: iconRight ? 0 : '8rpx', marginLeft: iconRight ? '8rpx' : 0 }">
      <slot name="icon"></slot>
    </view>
    <view v-if="loading" class="mui-button__loading">
      <view class="mui-spinner"></view>
    </view>
    <text class="mui-button__text">
      <slot></slot>
    </text>
  </view>
</template>

<script>
export default {
  name: 'MuiButton',
  props: {
    variant: {
      type: String,
      default: 'contained',
      validator: (v) => ['contained', 'outlined', 'text'].includes(v)
    },
    size: {
      type: String,
      default: 'medium',
      validator: (v) => ['small', 'medium', 'large'].includes(v)
    },
    color: {
      type: String,
      default: 'primary',
      validator: (v) => ['primary', 'secondary', 'error', 'warning', 'info', 'success'].includes(v)
    },
    disabled: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    icon: {
      type: Boolean,
      default: false
    },
    iconRight: {
      type: Boolean,
      default: false
    }
  },
  emits: ['click'],
  methods: {
    handleClick(e) {
      if (!this.disabled && !this.loading) {
        this.$emit('click', e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-sizing: border-box;
  outline: 0;
  border: 0;
  cursor: pointer;
  user-select: none;
  vertical-align: middle;
  text-decoration: none;
  font-family: inherit;
  letter-spacing: 1rpx;
  text-transform: uppercase;
  transition: all 0.25s ease;
  border-radius: $mui-radius-md;
  overflow: hidden;
  
  &:active {
    opacity: 0.8;
  }

  &__icon {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  &__loading {
    margin-right: 8rpx;
  }

  /* Variants */
  &--contained {
    box-shadow: $mui-shadow-1;
    
    &:active {
      box-shadow: $mui-shadow-2;
    }
  }

  &--outlined {
    background-color: transparent;
    border: 2rpx solid;
  }

  &--text {
    background-color: transparent;
    box-shadow: none;
  }

  /* Sizes */
  &--small {
    height: 64rpx;
    padding: 0 24rpx;
    font-size: 24rpx;
    
    .mui-button__text {
      font-size: 24rpx;
    }
  }

  &--medium {
    height: $mui-button-height;
    padding: 0 32rpx;
    font-size: 28rpx;
    
    .mui-button__text {
      font-size: 28rpx;
    }
  }

  &--large {
    height: 104rpx;
    padding: 0 40rpx;
    font-size: 32rpx;
    
    .mui-button__text {
      font-size: 32rpx;
    }
  }

  /* Colors */
  &--primary {
    &.mui-button--contained {
      background-color: $mui-primary;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-primary;
      color: $mui-primary;
    }
    &.mui-button--text {
      color: $mui-primary;
    }
  }

  &--secondary {
    &.mui-button--contained {
      background-color: $mui-secondary;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-secondary;
      color: $mui-secondary;
    }
    &.mui-button--text {
      color: $mui-secondary;
    }
  }

  &--error {
    &.mui-button--contained {
      background-color: $mui-error;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-error;
      color: $mui-error;
    }
    &.mui-button--text {
      color: $mui-error;
    }
  }

  &--warning {
    &.mui-button--contained {
      background-color: $mui-warning;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-warning;
      color: $mui-warning;
    }
    &.mui-button--text {
      color: $mui-warning;
    }
  }

  &--info {
    &.mui-button--contained {
      background-color: $mui-info;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-info;
      color: $mui-info;
    }
    &.mui-button--text {
      color: $mui-info;
    }
  }

  &--success {
    &.mui-button--contained {
      background-color: $mui-success;
      color: $mui-text-on-primary;
    }
    &.mui-button--outlined {
      border-color: $mui-success;
      color: $mui-success;
    }
    &.mui-button--text {
      color: $mui-success;
    }
  }

  /* States */
  &--disabled {
    opacity: 0.5;
    pointer-events: none;
    
    &.mui-button--contained {
      background-color: $mui-surface-variant;
      color: $mui-text-disabled;
    }
  }

  &--full {
    width: 100%;
  }
}

/* Loading Spinner */
.mui-spinner {
  width: 32rpx;
  height: 32rpx;
  border: 3rpx solid rgba(255, 255, 255, 0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: mui-spin 0.8s linear infinite;
}

@keyframes mui-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
