<template>
  <view 
    class="mui-icon-button"
    :class="[
      `mui-icon-button--${size}`,
      `mui-icon-button--${color}`,
      { 'mui-icon-button--disabled': disabled }
    ]"
    :disabled="disabled"
    @click="handleClick"
  >
    <slot></slot>
  </view>
</template>

<script>
export default {
  name: 'MuiIconButton',
  props: {
    size: {
      type: String,
      default: 'medium',
      validator: (v) => ['small', 'medium', 'large'].includes(v)
    },
    color: {
      type: String,
      default: 'default',
      validator: (v) => ['default', 'primary', 'secondary', 'error', 'warning', 'info', 'success', 'inherit'].includes(v)
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  emits: ['click'],
  methods: {
    handleClick(e) {
      if (!this.disabled) {
        this.$emit('click', e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-icon-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background-color: transparent;
  color: $mui-text-primary;
  transition: all 0.2s ease;
  cursor: pointer;
  user-select: none;

  &:active {
    background-color: rgba(0, 0, 0, 0.08);
  }

  /* Sizes */
  &--small {
    width: 64rpx;
    height: 64rpx;
    font-size: 32rpx;
  }

  &--medium {
    width: 80rpx;
    height: 80rpx;
    font-size: 40rpx;
  }

  &--large {
    width: 96rpx;
    height: 96rpx;
    font-size: 48rpx;
  }

  /* Colors */
  &--default {
    color: $mui-text-primary;
  }

  &--primary {
    color: $mui-primary;
  }

  &--secondary {
    color: $mui-secondary;
  }

  &--error {
    color: $mui-error;
  }

  &--warning {
    color: $mui-warning;
  }

  &--info {
    color: $mui-info;
  }

  &--success {
    color: $mui-success;
  }

  &--inherit {
    color: inherit;
  }

  /* States */
  &--disabled {
    opacity: 0.5;
    pointer-events: none;
  }
}
</style>
