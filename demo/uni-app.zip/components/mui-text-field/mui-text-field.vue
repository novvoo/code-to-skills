<template>
  <view class="mui-text-field" :class="{ 'mui-text-field--error': hasError, 'mui-text-field--full': fullWidth }">
    <view 
      class="mui-text-field__wrapper"
      :class="[
        `mui-text-field--${variant}`,
        { 'mui-text-field--focused': isFocused, 'mui-text-field--disabled': disabled }
      ]"
    >
      <view 
        v-if="label" 
        class="mui-text-field__label"
        :class="{ 'mui-text-field__label--floated': isFocused || hasValue }"
      >
        {{ label }}
      </view>
      
      <view class="mui-text-field__input-wrapper">
        <view v-if="prefixIcon" class="mui-text-field__icon mui-text-field__icon--prefix">
          <slot name="prefixIcon"></slot>
        </view>
        
        <input
          class="mui-text-field__input"
          :type="type"
          :value="modelValue"
          :placeholder="!label ? placeholder : ''"
          :disabled="disabled"
          :maxlength="maxlength"
          :password="type === 'password'"
          @input="handleInput"
          @focus="handleFocus"
          @blur="handleBlur"
        />
        
        <view v-if="suffixIcon || (type === 'password' && showPasswordToggle)" class="mui-text-field__icon mui-text-field__icon--suffix">
          <slot v-if="suffixIcon" name="suffixIcon"></slot>
          <view v-else @click="togglePassword" class="mui-text-field__password-toggle">
            <text>{{ showPassword ? '👁️' : '👁️‍🗨️' }}</text>
          </view>
        </view>
      </view>
      
      <view v-if="variant === 'outlined'" class="mui-text-field__outline">
        <view class="mui-text-field__outline-leading"></view>
        <view v-if="label" class="mui-text-field__outline-notch">
          <view class="mui-text-field__outline-notch-label">{{ label }}</view>
        </view>
        <view class="mui-text-field__outline-trailing"></view>
      </view>
    </view>
    
    <view v-if="helperText || (hasError && errorText)" class="mui-text-field__helper">
      <text :class="{ 'mui-text-field__helper--error': hasError }">
        {{ hasError ? errorText : helperText }}
      </text>
      <text v-if="hasCounter" class="mui-text-field__counter">{{ charCount }}/{{ maxlength }}</text>
    </view>
  </view>
</template>

<script>
export default {
  name: 'MuiTextField',
  props: {
    modelValue: {
      type: [String, Number],
      default: ''
    },
    label: {
      type: String,
      default: ''
    },
    placeholder: {
      type: String,
      default: ''
    },
    variant: {
      type: String,
      default: 'outlined',
      validator: (v) => ['filled', 'outlined', 'standard'].includes(v)
    },
    type: {
      type: String,
      default: 'text'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    error: {
      type: Boolean,
      default: false
    },
    errorText: {
      type: String,
      default: ''
    },
    helperText: {
      type: String,
      default: ''
    },
    prefixIcon: {
      type: Boolean,
      default: false
    },
    suffixIcon: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    maxlength: {
      type: Number,
      default: 200
    },
    hasCounter: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isFocused: false,
      showPassword: false
    }
  },
  computed: {
    hasError() {
      return this.error && this.errorText
    },
    hasValue() {
      return this.modelValue !== '' && this.modelValue !== null && this.modelValue !== undefined
    },
    charCount() {
      return String(this.modelValue).length
    }
  },
  methods: {
    handleInput(e) {
      this.$emit('update:modelValue', e.detail.value)
      this.$emit('input', e.detail.value)
    },
    handleFocus() {
      this.isFocused = true
      this.$emit('focus')
    },
    handleBlur() {
      this.isFocused = false
      this.$emit('blur')
    },
    togglePassword() {
      this.showPassword = !this.showPassword
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.mui-text-field {
  position: relative;
  margin-bottom: $mui-spacing-md;

  &--full {
    width: 100%;
  }

  &__wrapper {
    position: relative;
    display: flex;
    align-items: center;
  }

  &--filled {
    background-color: rgba($mui-primary, 0.09);
    border-radius: $mui-radius-sm $mui-radius-sm 0 0;
    min-height: $mui-input-height;
  }

  &--outlined {
    min-height: $mui-input-height;
  }

  &--standard {
    min-height: $mui-input-height;
  }

  &--focused {
    &.mui-text-field--filled {
      background-color: rgba($mui-primary, 0.12);
    }
  }

  &--disabled {
    opacity: 0.5;
    pointer-events: none;
  }

  &__label {
    position: absolute;
    left: 16rpx;
    font-size: $mui-font-base;
    color: $mui-text-secondary;
    transition: all 0.2s ease;
    pointer-events: none;
    z-index: 1;
    
    &--floated {
      font-size: $mui-font-xs;
      transform: translateY(-40rpx);
      color: $mui-primary;
    }
  }

  &__input-wrapper {
    display: flex;
    align-items: center;
    width: 100%;
    height: $mui-input-height;
    padding: 0 16rpx;
  }

  &__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    color: $mui-text-secondary;
    
    &--prefix {
      margin-right: 16rpx;
    }
    
    &--suffix {
      margin-left: 16rpx;
    }
  }

  &__password-toggle {
    padding: 8rpx;
  }

  &__input {
    flex: 1;
    height: 100%;
    font-size: $mui-font-base;
    color: $mui-text-primary;
    background: transparent;
    border: none;
    outline: none;
  }

  /* Outlined variant */
  &__outline {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    pointer-events: none;
    
    &-leading,
    &-trailing {
      border: 2rpx solid $mui-border;
      transition: border-color 0.2s ease;
    }
    
    &-leading {
      width: 12rpx;
      border-radius: $mui-radius-sm 0 0 $mui-radius-sm;
      border-right: none;
    }
    
    &-trailing {
      flex: 1;
      border-radius: 0 $mui-radius-sm $mui-radius-sm 0;
      border-left: none;
    }
    
    &-notch {
      padding: 0 8rpx;
      
      &-label {
        height: 50%;
        border-bottom: 2rpx solid $mui-border;
        transition: border-color 0.2s ease;
      }
    }
  }

  .mui-text-field--focused &__outline {
    &-leading,
    &-trailing {
      border-color: $mui-primary;
      border-width: 2rpx;
    }
    
    &-notch-label {
      border-color: $mui-primary;
    }
  }

  .mui-text-field--error &__outline {
    &-leading,
    &-trailing {
      border-color: $mui-error;
    }
    
    &-notch-label {
      border-color: $mui-error;
    }
  }

  .mui-text-field--focused.mui-text-field--error &__outline {
    &-leading,
    &-trailing {
      border-color: $mui-error;
    }
    
    &-notch-label {
      border-color: $mui-error;
    }
  }

  /* Filled and Standard bottom line */
  &--filled::after,
  &--standard::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 2rpx;
    background-color: $mui-border;
    transition: all 0.2s ease;
  }

  &--filled::before,
  &--standard::before {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 2rpx;
    background-color: $mui-primary;
    transform: scaleX(0);
    transition: transform 0.2s ease;
    z-index: 1;
  }

  .mui-text-field--focused&--filled::before,
  .mui-text-field--focused&--standard::before {
    transform: scaleX(1);
  }

  .mui-text-field--error&--filled::before,
  .mui-text-field--error&--standard::before {
    background-color: $mui-error;
  }

  /* Helper text */
  &__helper {
    display: flex;
    justify-content: space-between;
    padding: 4rpx 16rpx 0;
    font-size: $mui-font-xs;
    color: $mui-text-secondary;
    
    &--error {
      color: $mui-error;
    }
  }

  &__counter {
    color: $mui-text-secondary;
  }

  /* Label color for error state */
  .mui-text-field--error &__label {
    color: $mui-error;
  }

  .mui-text-field--error.mui-text-field--focused &__label--floated {
    color: $mui-error;
  }
}
</style>
