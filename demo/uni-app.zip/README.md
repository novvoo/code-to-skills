# MUI UNI-APP

基于 Material Design 风格的 uni-app Vue 3 组件库项目。

## 特性

- 🎨 Material Design 3 设计风格
- 📱 跨平台支持 (H5、小程序、App)
- ⚡ Vue 3 + uni-app
- 🎯 常用组件完整实现
- 📦 开箱即用

## 项目结构

```
mui-uniapp/
├── components/          # 自定义组件
│   ├── mui-button/
│   ├── mui-card/
│   ├── mui-text-field/
│   ├── mui-chip/
│   ├── mui-avatar/
│   ├── mui-icon-button/
│   └── mui-divider/
├── pages/              # 页面
│   ├── index/
│   └── components/
├── static/             # 静态资源
├── App.vue             # 应用配置
├── main.js             # 入口文件
├── index.html          # HTML 入口 (Vue 3 H5)
├── vite.config.js      # Vite 配置
├── manifest.json       # 应用清单
├── pages.json          # 页面路由
├── uni.scss            # 全局样式变量
├── package.json        # 依赖配置
└── README.md           # 项目说明
```

## 组件列表

### 基础组件

- `mui-button` - 按钮组件
- `mui-card` - 卡片组件
- `mui-text-field` - 输入框组件
- `mui-chip` - 标签组件
- `mui-avatar` - 头像组件
- `mui-icon-button` - 图标按钮组件
- `mui-divider` - 分割线组件

## 快速开始

### 方式一：使用 HBuilderX (推荐) ⭐

**不需要 npm install!**

1. 下载并安装 [HBuilderX](https://www.dcloud.io/hbuilderx.html)
2. 打开 HBuilderX
3. 文件 → 打开目录 → 选择本项目目录
4. 点击工具栏 → 运行 → 运行到浏览器 → 选择浏览器

**优点：**
- 零配置，开箱即用
- 官方 IDE 支持
- 自动处理依赖
- 支持多端编译

### 方式二：使用 CLI (需要 npm install)

> 注意：需要正确配置 DCloud 官方源

1. 配置 npm 源（如果需要）
```bash
npm config set registry https://registry.npmmirror.com
```

2. 安装依赖
```bash
npm install
```

3. 开发运行
```bash
# H5
npm run dev:h5

# 微信小程序
npm run dev:mp-weixin
```

## 使用示例

### Button 按钮

```vue
<template>
  <mui-button variant="contained" color="primary">
    主要按钮
  </mui-button>
</template>
```

### Card 卡片

```vue
<template>
  <mui-card>
    <template v-slot:header>
      <!-- 卡片头部 -->
    </template>
    
    <!-- 卡片内容 -->
    
    <template v-slot:actions>
      <!-- 卡片操作 -->
    </template>
  </mui-card>
</template>
```

### TextField 输入框

```vue
<template>
  <mui-text-field
    v-model="value"
    label="用户名"
    variant="outlined"
    placeholder="请输入用户名"
  />
</template>
```

## 主题定制

编辑 `uni.scss` 文件可以自定义主题：

```scss
// 主色调
$mui-primary: #1976D2;
$mui-secondary: #009688;

// 功能色
$mui-error: #D32F2F;
$mui-warning: #F57C00;
$mui-success: #2E7D32;

// 圆角
$mui-radius-sm: 8rpx;
$mui-radius-md: 12rpx;
$mui-radius-lg: 16rpx;
```

## 平台支持

| 平台 | 状态 |
|-----|-----|
| H5 | ✅ 支持 |
| 微信小程序 | ✅ 支持 |
| App (Android/iOS) | ✅ 支持 |
| 支付宝小程序 | ✅ 支持 |
| 百度小程序 | ✅ 支持 |
| 字节跳动小程序 | ✅ 支持 |

## 常见问题

### 1. npm install 失败？
**使用 HBuilderX 吧！** 不需要 npm install。

### 2. 找不到 @dcloudio/xxx 包？
uni-app 依赖由 HBuilderX 自动管理，使用 HBuilderX 开发即可。

### 3. 如何添加 tabBar？
在 `pages.json` 中添加 tabBar 配置，并准备对应的图标文件。

## 技术栈

- Vue 3
- uni-app
- SCSS
- Vite (可选)

## License

MIT
