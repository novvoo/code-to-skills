<script>
export default {
  onLaunch: function() {
    console.log('App Launch')
  },
  onShow: function() {
    console.log('App Show')
  },
  onHide: function() {
    console.log('App Hide')
  }
}
</script>

<style lang="scss">
@import './uni.scss';

/* 全局样式 */
page {
  background-color: $mui-background;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  color: $mui-text-primary;
}

/* 通用容器 */
.mui-container {
  padding: $mui-spacing-md;
}

.mui-container-fluid {
  padding: $mui-spacing-sm $mui-spacing-md;
}

/* 工具类 */
.mui-text-center {
  text-align: center;
}

.mui-text-right {
  text-align: right;
}

.mui-mt-1 { margin-top: $mui-spacing-xs; }
.mui-mt-2 { margin-top: $mui-spacing-sm; }
.mui-mt-3 { margin-top: $mui-spacing-md; }
.mui-mt-4 { margin-top: $mui-spacing-lg; }

.mui-mb-1 { margin-bottom: $mui-spacing-xs; }
.mui-mb-2 { margin-bottom: $mui-spacing-sm; }
.mui-mb-3 { margin-bottom: $mui-spacing-md; }
.mui-mb-4 { margin-bottom: $mui-spacing-lg; }

.mui-p-1 { padding: $mui-spacing-xs; }
.mui-p-2 { padding: $mui-spacing-sm; }
.mui-p-3 { padding: $mui-spacing-md; }
.mui-p-4 { padding: $mui-spacing-lg; }
</style>
