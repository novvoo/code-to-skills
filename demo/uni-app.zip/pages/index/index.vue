<template>
  <view class="container">
    <view class="hero">
      <text class="title">Material UI</text>
      <text class="subtitle">Material Design 风格的 uni-app 组件库</text>
    </view>

    <mui-card class="welcome-card">
      <template v-slot:header>
        <view class="card-header">
          <mui-avatar color="#1976D2">M</mui-avatar>
          <view class="header-info">
            <text class="header-title">欢迎使用</text>
            <text class="header-subtitle">开始构建你的应用</text>
          </view>
        </view>
      </template>
      
      <view class="card-content">
        <text class="content-text">
          这是一个基于 Material Design 风格的 uni-app 组件库示例项目，包含常用的 UI 组件和样式系统。
        </text>
      </view>
      
      <template v-slot:actions>
        <mui-button variant="text" @click="goToComponents">查看组件</mui-button>
        <mui-button variant="contained" @click="showToast">开始使用</mui-button>
      </template>
    </mui-card>

    <view class="features">
      <mui-card class="feature-card">
        <view class="feature-icon">🎨</view>
        <text class="feature-title">Material Design</text>
        <text class="feature-desc">遵循 Google Material Design 3 设计规范</text>
      </mui-card>
      
      <mui-card class="feature-card">
        <view class="feature-icon">📱</view>
        <text class="feature-title">跨平台</text>
        <text class="feature-desc">支持 H5、小程序、App 多端运行</text>
      </mui-card>
      
      <mui-card class="feature-card">
        <view class="feature-icon">⚡</view>
        <text class="feature-title">高性能</text>
        <text class="feature-desc">基于 Vue 3 + uni-app 构建</text>
      </mui-card>
    </view>

    <view class="quick-actions">
      <text class="section-title">快速操作</text>
      
      <view class="action-buttons">
        <mui-button variant="contained" color="primary" full-width @click="handlePrimary">
          主要按钮
        </mui-button>
        <mui-button variant="outlined" color="secondary" full-width @click="handleSecondary">
          次要按钮
        </mui-button>
        <mui-button variant="text" color="success" full-width @click="handleSuccess">
          成功按钮
        </mui-button>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  methods: {
    goToComponents() {
      uni.switchTab({
        url: '/pages/components/components'
      })
    },
    showToast() {
      uni.showToast({
        title: '欢迎使用 MUI uni-app!',
        icon: 'success'
      })
    },
    handlePrimary() {
      uni.showToast({
        title: '点击了主要按钮',
        icon: 'none'
      })
    },
    handleSecondary() {
      uni.showToast({
        title: '点击了次要按钮',
        icon: 'none'
      })
    },
    handleSuccess() {
      uni.showToast({
        title: '操作成功!',
        icon: 'success'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.container {
  min-height: 100vh;
  background-color: $mui-background;
  padding: $mui-spacing-md;
}

.hero {
  text-align: center;
  padding: $mui-spacing-xl 0;
}

.title {
  display: block;
  font-size: $mui-font-3xl;
  font-weight: 500;
  color: $mui-primary;
  margin-bottom: $mui-spacing-sm;
}

.subtitle {
  display: block;
  font-size: $mui-font-base;
  color: $mui-text-secondary;
}

.welcome-card {
  margin-bottom: $mui-spacing-xl;
}

.card-header {
  display: flex;
  align-items: center;
  padding: $mui-spacing-sm 0;
}

.header-info {
  margin-left: $mui-spacing-md;
  flex: 1;
}

.header-title {
  display: block;
  font-size: $mui-font-lg;
  font-weight: 500;
  color: $mui-text-primary;
}

.header-subtitle {
  display: block;
  font-size: $mui-font-sm;
  color: $mui-text-secondary;
}

.card-content {
  padding-top: $mui-spacing-sm;
}

.content-text {
  font-size: $mui-font-base;
  line-height: 1.6;
  color: $mui-text-primary;
}

.features {
  display: flex;
  gap: $mui-spacing-md;
  margin-bottom: $mui-spacing-xl;
}

.feature-card {
  flex: 1;
  padding: $mui-spacing-md;
  text-align: center;
}

.feature-icon {
  font-size: 48rpx;
  margin-bottom: $mui-spacing-sm;
}

.feature-title {
  display: block;
  font-size: $mui-font-base;
  font-weight: 500;
  color: $mui-text-primary;
  margin-bottom: $mui-spacing-xs;
}

.feature-desc {
  display: block;
  font-size: $mui-font-sm;
  color: $mui-text-secondary;
  line-height: 1.5;
}

.quick-actions {
  margin-bottom: $mui-spacing-xl;
}

.section-title {
  display: block;
  font-size: $mui-font-lg;
  font-weight: 500;
  color: $mui-text-primary;
  margin-bottom: $mui-spacing-md;
}

.action-buttons {
  display: flex;
  flex-direction: column;
  gap: $mui-spacing-md;
}
</style>
