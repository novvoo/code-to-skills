<template>
  <view class="container">
    <scroll-view scroll-y class="scroll-view">
      <!-- Buttons Section -->
      <view class="section">
        <text class="section-title">按钮 Buttons</text>
        
        <mui-card>
          <view class="component-demo">
            <text class="demo-label">Contained Buttons</text>
            <view class="button-row">
              <mui-button variant="contained" color="primary">Primary</mui-button>
              <mui-button variant="contained" color="secondary">Secondary</mui-button>
              <mui-button variant="contained" color="error">Error</mui-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Outlined Buttons</text>
            <view class="button-row">
              <mui-button variant="outlined" color="primary">Primary</mui-button>
              <mui-button variant="outlined" color="secondary">Secondary</mui-button>
              <mui-button variant="outlined" color="success">Success</mui-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Text Buttons</text>
            <view class="button-row">
              <mui-button variant="text" color="primary">Primary</mui-button>
              <mui-button variant="text" color="warning">Warning</mui-button>
              <mui-button variant="text" color="info">Info</mui-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Sizes</text>
            <view class="button-row">
              <mui-button variant="contained" size="small">Small</mui-button>
              <mui-button variant="contained" size="medium">Medium</mui-button>
              <mui-button variant="contained" size="large">Large</mui-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Disabled</text>
            <view class="button-row">
              <mui-button variant="contained" disabled>Disabled</mui-button>
              <mui-button variant="outlined" disabled>Disabled</mui-button>
              <mui-button variant="text" disabled>Disabled</mui-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">With Loading</text>
            <view class="button-row">
              <mui-button variant="contained" loading>Loading</mui-button>
              <mui-button variant="outlined" loading>Loading</mui-button>
            </view>
          </view>
        </mui-card>
      </view>

      <!-- Chips Section -->
      <view class="section">
        <text class="section-title">标签 Chips</text>
        
        <mui-card>
          <view class="component-demo">
            <text class="demo-label">Filled Chips</text>
            <view class="chip-row">
              <mui-chip color="primary">Primary</mui-chip>
              <mui-chip color="secondary">Secondary</mui-chip>
              <mui-chip color="success">Success</mui-chip>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Outlined Chips</text>
            <view class="chip-row">
              <mui-chip variant="outlined" color="primary">Primary</mui-chip>
              <mui-chip variant="outlined" color="error">Error</mui-chip>
              <mui-chip variant="outlined" color="warning">Warning</mui-chip>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Deletable Chips</text>
            <view class="chip-row">
              <mui-chip deletable @delete="deleteChip('chip1')">Tag 1</mui-chip>
              <mui-chip deletable @delete="deleteChip('chip2')">Tag 2</mui-chip>
              <mui-chip deletable @delete="deleteChip('chip3')">Tag 3</mui-chip>
            </view>
          </view>
        </mui-card>
      </view>

      <!-- Text Fields Section -->
      <view class="section">
        <text class="section-title">输入框 Text Fields</text>
        
        <mui-card>
          <view class="component-demo">
            <mui-text-field
              v-model="textValue"
              label="Outlined"
              variant="outlined"
              placeholder="请输入内容"
              @input="onInput"
            />
            
            <mui-text-field
              v-model="filledValue"
              label="Filled"
              variant="filled"
              placeholder="请输入内容"
            />
            
            <mui-text-field
              v-model="standardValue"
              label="Standard"
              variant="standard"
              placeholder="请输入内容"
            />
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <mui-text-field
              v-model="passwordValue"
              label="Password"
              type="password"
              variant="outlined"
            />
            
            <mui-text-field
              v-model="errorValue"
              label="Error State"
              variant="outlined"
              error
              error-text="这是一个错误提示"
            />
            
            <mui-text-field
              v-model="helperValue"
              label="With Helper Text"
              variant="outlined"
              helper-text="这是帮助文本"
            />
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <mui-text-field
              v-model="counterValue"
              label="With Counter"
              variant="outlined"
              has-counter
              maxlength="50"
            />
            
            <mui-text-field
              v-model="disabledValue"
              label="Disabled"
              variant="outlined"
              disabled
              disabled-text="输入框已禁用"
            />
          </view>
        </mui-card>
      </view>

      <!-- Avatar Section -->
      <view class="section">
        <text class="section-title">头像 Avatar</text>
        
        <mui-card>
          <view class="component-demo">
            <text class="demo-label">Circular</text>
            <view class="avatar-row">
              <mui-avatar size="small" color="#1976D2">S</mui-avatar>
              <mui-avatar size="medium" color="#009688">M</mui-avatar>
              <mui-avatar size="large" color="#D32F2F">L</mui-avatar>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Variants</text>
            <view class="avatar-row">
              <mui-avatar variant="circular" color="#1976D2">C</mui-avatar>
              <mui-avatar variant="rounded" color="#009688">R</mui-avatar>
              <mui-avatar variant="square" color="#D32F2F">S</mui-avatar>
            </view>
          </view>
        </mui-card>
      </view>

      <!-- Icon Buttons Section -->
      <view class="section">
        <text class="section-title">图标按钮 Icon Buttons</text>
        
        <mui-card>
          <view class="component-demo">
            <view class="icon-button-row">
              <mui-icon-button color="primary">🔍</mui-icon-button>
              <mui-icon-button color="secondary">❤️</mui-icon-button>
              <mui-icon-button color="error">🗑️</mui-icon-button>
              <mui-icon-button color="success">✓</mui-icon-button>
              <mui-icon-button color="warning">⚠️</mui-icon-button>
              <mui-icon-button color="info">ℹ️</mui-icon-button>
            </view>
          </view>
          
          <mui-divider />
          
          <view class="component-demo">
            <text class="demo-label">Sizes</text>
            <view class="icon-button-row">
              <mui-icon-button size="small">⭐</mui-icon-button>
              <mui-icon-button size="medium">⭐</mui-icon-button>
              <mui-icon-button size="large">⭐</mui-icon-button>
            </view>
          </view>
        </mui-card>
      </view>

      <!-- Card Variants Section -->
      <view class="section">
        <text class="section-title">卡片 Card Variants</text>
        
        <mui-card class="card-demo">
          <view class="card-media" style="background-color: #1976D2; height: 200rpx;">
            <text style="color: white; font-size: 48rpx;">Media</text>
          </view>
          <view class="card-content">
            <text class="card-title">Card with Media</text>
            <text class="card-text">这是一个带有图片区域的卡片示例</text>
          </view>
          <template v-slot:actions>
            <mui-button variant="text">Action 1</mui-button>
            <mui-button variant="text">Action 2</mui-button>
          </template>
        </mui-card>
        
        <mui-card outlined class="card-demo">
          <view class="card-content">
            <text class="card-title">Outlined Card</text>
            <text class="card-text">这是一个带边框的卡片</text>
          </view>
        </mui-card>
      </view>
    </scroll-view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      textValue: '',
      filledValue: '',
      standardValue: '',
      passwordValue: '',
      errorValue: '',
      helperValue: '',
      counterValue: '',
      disabledValue: '已禁用的值'
    }
  },
  methods: {
    onInput(value) {
      console.log('Input:', value)
    },
    deleteChip(chipId) {
      uni.showToast({
        title: `删除了 ${chipId}`,
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/uni.scss';

.container {
  min-height: 100vh;
  background-color: $mui-background;
}

.scroll-view {
  height: 100vh;
  padding: $mui-spacing-md;
}

.section {
  margin-bottom: $mui-spacing-xl;
}

.section-title {
  display: block;
  font-size: $mui-font-lg;
  font-weight: 500;
  color: $mui-text-primary;
  margin-bottom: $mui-spacing-md;
  padding-left: $mui-spacing-xs;
}

.component-demo {
  padding: $mui-spacing-md 0;
}

.demo-label {
  display: block;
  font-size: $mui-font-sm;
  color: $mui-text-secondary;
  margin-bottom: $mui-spacing-md;
}

.button-row {
  display: flex;
  gap: $mui-spacing-md;
  flex-wrap: wrap;
}

.chip-row {
  display: flex;
  gap: $mui-spacing-sm;
  flex-wrap: wrap;
}

.avatar-row {
  display: flex;
  gap: $mui-spacing-md;
  align-items: center;
}

.icon-button-row {
  display: flex;
  gap: $mui-spacing-sm;
  align-items: center;
}

.card-demo {
  margin-bottom: $mui-spacing-md;
}

.card-media {
  display: flex;
  align-items: center;
  justify-content: center;
}

.card-title {
  display: block;
  font-size: $mui-font-lg;
  font-weight: 500;
  color: $mui-text-primary;
  margin-bottom: $mui-spacing-sm;
}

.card-text {
  display: block;
  font-size: $mui-font-base;
  color: $mui-text-secondary;
  line-height: 1.5;
}
</style>
